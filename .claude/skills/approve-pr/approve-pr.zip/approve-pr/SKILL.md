---
name: approve-pr
description: |
  Full PR review cycle for the LusitAI aipentest project. Given a PR number (or the
  current branch), this skill fetches the diff, identifies the User Story being
  implemented, reads the acceptance criteria and required tests from USER-STORIES.md,
  runs the test suite, reads every changed source file, and issues a structured
  APPROVE / REQUEST CHANGES verdict. Use when asked to "review this PR", "aprovar PR",
  "analisar PR", "check this PR", or "dar veredicto do PR".
---

# Approve PR

## Overview

End-to-end PR review tailored to this project's conventions. Covers: diff analysis,
User Story traceability, test execution, architecture coherence, and a final APPROVE /
REQUEST CHANGES verdict with actionable inline comments.

## Argument

The skill accepts an optional PR number in the invocation arguments (e.g. `/approve-pr 42`).

- If a number was provided, use it as `PR_NUM`.
- Otherwise, detect it from the current branch with the bash block in Phase 1.

Do NOT run bash to extract the argument — read it from the invocation text directly.

---

## Workflow

Execute the six phases below in order. Collect evidence at each phase; synthesise into
the verdict only at the end.

---

### Phase 1 — Fetch the PR

If `PR_NUM` was not provided as an argument, detect it:

```bash
git branch --show-current
```

Then look up the open PR for that branch:

```bash
gh pr list --head "<branch-name>" --json number,title,baseRefName,headRefName --jq '.[0]'
```

Once `PR_NUM` is known, fetch metadata and diff stats:

```bash
gh pr view <PR_NUM> --json title,body,baseRefName,headRefName,author,state,labels,reviewDecision
```

```bash
gh pr diff <PR_NUM> --stat
```

For the full diff, fetch it and read carefully. If the diff is very large (>300 lines),
fetch only the file list first and read each file individually in Phase 3 instead:

```bash
gh pr diff <PR_NUM> --name-only
```

```bash
gh pr diff <PR_NUM>
```

Note from the diff:
- Which files changed and why
- The branch name encodes the User Story ID (e.g. `feature/US-055-...` → `US-055`)

---

### Phase 2 — Read the User Story

Extract the US number from the branch name or PR title (pattern: `US-\d+`).

Then read the User Story block from the docs:

```bash
grep -n "### <US_ID>:" docs/USER-STORIES.md
```

Use the line number returned to read from that line onwards (approximately 80 lines):

```bash
# Use Read tool with offset=<line> limit=90 on docs/USER-STORIES.md
```

From the User Story, extract and record:
- **Acceptance Criteria** — every checklist item that must be satisfied
- **Tests Required** — the specific test scenarios that must exist and pass
- **Technical Notes** — implementation constraints

---

### Phase 3 — Read Changed Source Files

List the changed files, split by category:

```bash
gh pr diff <PR_NUM> --name-only
```

For each file that is **not** under `tests/` and **not** under `docs/`, use the Read tool
to read it in full. Do not skip any source file.

For each file, evaluate:
- Does it follow the existing module pattern described in CLAUDE.md §Module Responsibilities?
- Is async used consistently (`async def`, `await`, `AsyncSession`)?
- Are Pydantic v2 models used for all data structures at boundaries?
- New tools: do they use factory closures matching `tools/terminal.py` or `tools/browser.py`?
- New barriers: are they registered in `BarrierAwareToolNode` and do they extract the right args?
- No REST endpoints — external interface is MCP only
- Doc files must have Obsidian frontmatter `tags: [...]`

---

### Phase 4 — Read and Run Tests

First, list test files changed or added in this PR:

```bash
gh pr diff <PR_NUM> --name-only | grep '^tests/'
```

Use the Read tool to read each test file. Verify:
- Tests cover each item in the User Story's **Tests Required** list
- Tests are in the correct layer (unit / integration / agent / e2e) per CLAUDE.md §Testing Strategy
- No `@pytest.mark.asyncio` decorators — `asyncio_mode = "auto"` is already configured
- Mocks/fixtures follow existing patterns (polyfactory, respx, testcontainers)

Then run the tests. Run only the files that are part of this PR first:

```bash
pytest <test-file-1> <test-file-2> -v --tb=short 2>&1 | tail -80
```

If they pass, run the full suite for each affected layer to catch regressions:

```bash
pytest tests/unit/ -v --tb=short -q 2>&1 | tail -40
```

Run integration and agent layers only if files under those paths changed:

```bash
pytest tests/integration/ -v -m integration --tb=short -q 2>&1 | tail -40
pytest tests/agent/ -v -m agent --tb=short -q 2>&1 | tail -40
```

---

### Phase 5 — Architecture Coherence Check

Run lint and type checks:

```bash
ruff check src/ tests/ 2>&1 | tail -30
```

```bash
mypy src/pentest/ --ignore-missing-imports 2>&1 | tail -30
```

Then fill in this table based on what was observed in Phases 3 and 4:

| # | Check | Result |
|---|-------|--------|
| 1 | All new async functions use `async def` and are awaited correctly | |
| 2 | New DB queries use `AsyncSession` and the existing session context manager | |
| 3 | New Pydantic models use v2 syntax (`model_config`, `Field`, no `__validators__`) | |
| 4 | New tools use factory closures matching `tools/terminal.py` or `tools/browser.py` | |
| 5 | New barriers registered in `BarrierAwareToolNode` and extract the right args | |
| 6 | No direct `requests` / sync HTTP calls — only `httpx.AsyncClient` | |
| 7 | Imports follow project structure (no circular, no star imports) | |
| 8 | `ruff check` passes with no new errors | |
| 9 | `mypy` passes with no new errors | |
| 10 | Doc files (if any) have correct Obsidian frontmatter tags | |

Use YES / NO / N/A for each row, with a one-line justification.

---

### Phase 6 — Verdict

Produce the following structured report:

#### Summary

One paragraph: what this PR implements, which US it closes, overall quality impression.

#### Acceptance Criteria Coverage

For each criterion from the User Story:
- ✅ Met
- ❌ Not Met — quote the specific missing piece
- ⚠️ Partial — quote what is missing

#### Test Coverage

For each item in **Tests Required**:
- ✅ Exists and passes
- ❌ Missing
- ⚠️ Exists but fails — include the failure output

#### Architecture Issues

The completed table from Phase 5. If all YES/N/A: "No issues found."

#### Inline Comments

For any specific line-level concerns:

```
src/pentest/tools/barriers.py:42 — reason or suggestion
```

#### Final Verdict

```
VERDICT: APPROVE
```

or

```
VERDICT: REQUEST CHANGES

Blocking issues:
1. ...

Non-blocking suggestions:
1. ...
```

**APPROVE** requires all of the following:
- Every acceptance criterion is ✅ Met
- Every required test exists and passes
- `ruff` and `mypy` produce no new errors
- No blocking architecture issues

**REQUEST CHANGES** when any of the above is not satisfied.
